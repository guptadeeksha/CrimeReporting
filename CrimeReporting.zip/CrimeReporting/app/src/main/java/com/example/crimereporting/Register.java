package com.example.crimereporting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        Button Sub = findViewById(R.id.submit);
        Sub.setOnClickListener(fnsubmit);
    }

    public void Register(View view) {
    }

    private View.OnClickListener fnsubmit= new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent1;

            intent1 =new Intent(Register.this, Middle.class);
            startActivity(intent1);
        }
    };
}
